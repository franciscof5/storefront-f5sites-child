var $wholeHead = $('.whole-head');
var $body = $('.body');
var $arms = $('.arms');
var $lLeg = $('.l-leg');
var $rLeg = $('.r-leg');

$(function(){
  $wholeHead.click(function(){
    
  })
});